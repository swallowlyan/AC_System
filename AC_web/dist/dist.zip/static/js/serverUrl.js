window.g={
    baseUrl:"http://121.41.2.65:9090/api"
}